<?php

namespace App\Controller;

use App\Entity\Produit;
use App\Entity\ProduitCat;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(ManagerRegistry $doctrine): Response
    {
        $produits = $doctrine->getRepository(Produit::class)->findAll();
        $produitsCat = $doctrine->getRepository(ProduitCat::class)->findAll();

        return $this->render('home/index.html.twig', [
            'controller_name' => 'HomeController',
            'produits'=>$produits,
            'produitsCat'=>$produitsCat
        ]);
    }
}
