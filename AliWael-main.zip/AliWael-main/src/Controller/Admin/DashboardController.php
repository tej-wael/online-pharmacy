<?php

namespace App\Controller\Admin;

use App\Entity\Blogs;
use App\Entity\Contact;
use App\Entity\Orders;
use App\Entity\OrdersDetails;
use App\Entity\Pro;
use App\Entity\Produit;
use App\Entity\ProduitCat;
use App\Entity\User;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;

class DashboardController extends AbstractDashboardController
{
    public function __construct(
        private AdminUrlGenerator $adminUrlGenerator
    ) {
    }

    #[Route('/admin', name: 'admin')]
    public function index(): Response
    {
        $url = $this->adminUrlGenerator
            ->setController(OrdersCrudController::class)
            ->generateUrl();

        return $this->redirect($url);
        // return parent::index();
    }


    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('ProjetAliWeal');
    }

    public function configureMenuItems(): iterable
    {
        yield MenuItem::linkToDashboard('Dashboard', 'fa fa-home');
        yield MenuItem::linkToCrud('Orders', 'fas fa-list', Orders::class);
        // yield MenuItem::linkToCrud('OrdersDetails', 'fas fa-list', OrdersDetails::class);
        yield MenuItem::linkToCrud('Contact', 'fas fa-list', Contact::class);
        yield MenuItem::linkToCrud('Blogs', 'fas fa-list', Blogs::class);
        yield MenuItem::linkToCrud('Pro', 'fas fa-list', Pro::class);
        yield MenuItem::linkToCrud('Produit', 'fas fa-list', Produit::class);
        yield MenuItem::linkToCrud('ProduitCat', 'fas fa-list', ProduitCat::class);
        yield MenuItem::linkToCrud('User', 'fas fa-list', User::class);






    }
}
