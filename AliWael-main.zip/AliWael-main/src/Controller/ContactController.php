<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Contact;
use App\Form\ContactType;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;

class ContactController extends AbstractController
{
    #[Route('/contact', name: 'app_contact')]
    public function index(Request $req , ManagerRegistry $doctrine): Response
    {
        $em = $doctrine->getManager();
        $contact = new Contact();
        $form = $this->createForm(ContactType::class , $contact, [
            'action'=>$this->generateUrl('app_contact'),
            'method'=>'POST'
        ]);
        $form->handleRequest($req);
        if ($form->isSubmitted() && $form->isValid() ) {
            $em->persist($contact);
            $em->flush();
            $this->addFlash('success','Votre contact a ete enrigistrer avec success!');
            return $this->redirectToRoute('app_contact');
        }
        return $this->render('contact/index.html.twig', [
            'controller_name' => 'AutresController',
            'form'=>$form->createView(),
        ]);
    }
}