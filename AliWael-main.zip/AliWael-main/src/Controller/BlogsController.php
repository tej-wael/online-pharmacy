<?php

namespace App\Controller;

use App\Entity\Blogs;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class BlogsController extends AbstractController
{
    #[Route('/blogs', name: 'view_all')]
    public function index(Request $req, ManagerRegistry $doctrine): Response
    {
        $blogs = $doctrine->getRepository(Blogs::class)->findBy([],['id'=>'DESC']);
        return $this->render('blogs/index.html.twig', [
            'controller_name' => 'BlogsController',
            'blogs'=>$blogs,
        ]);
    }

    #[Route('/blogs/{id}', name: 'app_blogs_Details')]
    public function Details(Blogs $blog): Response
    {

        return $this->render('blogs/detail.html.twig', [
            'controller_name' => 'BlogsController',
            'blog' => $blog,
        ]);
    }
}
