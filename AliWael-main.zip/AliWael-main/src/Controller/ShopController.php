<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Produit;

class ShopController extends AbstractController
{
    #[Route('/shop', name: 'app_shop')]
    public function index( ManagerRegistry $doctrine): Response
    {
        $produits = $doctrine->getRepository(Produit::class)->findAll();
        return $this->render('shop/index.html.twig', [
            'controller_name' => 'ShopController',
            'produits'=>$produits
        ]);
    }

    #[Route('/shop/{id}', name: 'shop_details')]
    public function details(Produit $product): Response
    {
        // dump($product);die;
        return $this->render('shop/details.html.twig', compact('product'));
    }
}
